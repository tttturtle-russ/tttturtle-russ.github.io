# Read <LLM Powered Autonomous Agents>

## Overview

本文介绍了由大语言模型驱动的自动代理的原理，在大预言模型越来越流行和日渐强大的今天，使用大预言模型不仅可以进行文书，编码上的一些辅助，更可以成为一个通用的自主问题解决器，比如作为自动代理的驱动。

本文主要从代理系统（ Agent System ）的组成角度进行介绍，一个代理系统由3个部件组成：

- 规划器（ Planning ）
- 记忆（ Memory ）
- 工具调用 （ Tool Use ）

![Untitled](Read%20LLM%20Powered%20Autonomous%20Agents%2086be86301a6342758a6dadbff904c9a9/Untitled.png)

同时，本文还举出了三个LLM Powered Agent 实例：

- Secientific Discovery Agent：一个拥有多个外部专业工具的科学开发辅助工具，主要用于辅助化学药物的研发和合成。
- Generative Agent Simulation：一个用LLM驱动的虚拟任务模拟实验，其中有25个虚拟人物都由代理控制，用于模拟人类行为。
- Proof-of-Concept Exanples：使用AutoGPT对一些概念的验证的演示事例。

 

文章最后还提出了构建LLM-Powered-Agent存在的一些限制和挑战：

- 有限上下文长度：上下文长度的限制会限制对历史信息的总结，细节上的操作，API调用的上下文等方面。
- 长期计划和任务分解的挑战：对于意料之外的错误的处理和学习使得Agent无法有效的进行长期规划和求解。
- 自然语言接口的可靠性：大部分agent的输出都不一定可靠，因为LLM可能会处理错误，有时候甚至会变得“叛逆”。

## 组件一：规划器

> A complicated task usually involves many steps. An agent needs to know what they are and plan ahead.
> 

对于规划器的执行过程主要分两个部分：**任务分解（Task Decomposition）**和 **自我反省（Self-Reflection）**。

对于**任务分解**文中提到了两个概念：思维链（Chain of Thought，CoT）和思维树（Tree of Thought）。思维链是由 [Wei et al. 2022](https://arxiv.org/abs/2201.11903) 提出的，已经成为一个增强模型在复杂任务上的标准技术。模型被引导“一步步思考”来利用更多测试时间将复杂任务分解成小而简单的步骤。而思维树[Yao et al. 2023](https://arxiv.org/abs/2305.10601)，是对于CoT的扩展。其原理是在CoT将复杂问题分解成每个step后，对每个step再生成多个想法，从而形成一个树状结构。对树结构的搜索方法基于给定的prompt或多数票（majority vote）决定为BFS或是DFS。

其中还提到了一种方法：LLM+P [Liu et al. 2023](https://arxiv.org/abs/2304.11477) 。主要是使用了一个外部经典规划器来进行长期规划。这种方法使用 PDDL （Planning Domain Definition Language）作为中间接口进行规划问题的描述，主要步骤如下所示：

1. LLM将问题转化为 [“Problem PDDL”](https://planning.wiki/ref/pddl/problem)
2. 然后请求外部的经典规划器基于一个已存在的[“Domain PDDL"](https://planning.wiki/ref/pddl/domain)生成一个PDDL规划。
3. 将 2 中生成的 PDDL 规划翻译成自然语言

这个方法的核心在于将规划的任务交给外部的规划器，而不是LLM进行规划，这就要求步骤中的Domain PDDL和外部使用的规划器是适合且准确的。

**自我反省**对于人类是一个重要的方面，对于不如人类（目前来说）的机器，更是如此。对于自动代理来说，它通过完善过去做的决定以及改进之前的错误来迭代进化。

[ReAct](https://arxiv.org/abs/2210.03629) 通过将动作空间扩展为特定任务离散动作和语言空间组合，将推理和动作整合在LLM中。前者

让 LLM 拥有与环境交互的能力，例如使用 Wikipedia 的搜索 API；而后者则提示 LLM 生成自然语言的推理追踪。

ReAct 提示模板给 LLM 的思考整合了明确的步骤，大致如下：

```jsx
Thought: ...
Action: ...
Observation: ...
... (Repeated many times)
```

<aside>
💡 ReAct 方法是在 Act 方法的基础上进行了改进，加入了Thought这一栏，实验证明，ReAct 方法的表现要优于 Act 方法

</aside>

[Reflxion](https://arxiv.org/abs/2303.11366) 是一个通过给代理配备动态记忆和自我反省能力从而提高模型推理能力的框架，Reflxion 有一个标准强化学习设置，其中动作空间的设置和 ReAct 一样，具体原理如图所示。

![Untitled](Read%20LLM%20Powered%20Autonomous%20Agents%2086be86301a6342758a6dadbff904c9a9/Untitled%201.png)

在每一个动作$a_i$之后，代理都会计算其启发值$h_i$并根据结果选择性的重置环境开始一个新的试验。对于这个启发式函数$h$，其作用是发现模型中的效率低下和虚构问题并及时停止。

自我反思的具体创建是通过二元组实现的，每个二元组都是一个失败的轨迹和理想的反思构成，具体来说失败的轨迹就是尝试过的但失败的执行序列，理想的反思就是将来要执行的可能成功的执行序列。这些二元组被添加到代理的记忆中，作为上下文使用。

回顾链（ [Chian of Hindsight](https://arxiv.org/abs/2302.02676) ，CoH ）鼓励模型通过展现过去的一系列输出来改进现有输出，并且每个都具有反馈信息。人类的反馈信息使用一个集合$D_h=\{(x,y_i,r_i,z_i)\}_{i=1}^{n}$来表示，其中$x$表示一个prompt，每一个$y_i$都是模型提供的补全，$r_i$是人对$y_i$的评分，$z_i$则是相应的人类对回顾的反馈。假设集合中的$z_i$是从大到小排列的，则这个过程变成了一个有监督的微调过程，输入序列的形式为

$\tau_h=(x,z_i,y_i,z_j,y_j,...z_n,y_n)$，其中i ≤ j ≤ n。在模型预测$y_j$的时候，会根据$j$之前的序列进行输出优化和改进。

CoH 在训练过程中添加了正则化来控制模型过拟合问题，并且通过随机屏蔽过去的标记，预防捷径和复制行为的出现。

[Algorithm Distillation](https://arxiv.org/abs/2210.14215) 将该思想应用于强化学习的跨事件学习中，跨任务的执行序列这里我称之为$H$算法被封装在一个长期记忆政策里，这个方法的核心在于在每次代理和环境交互并且更加准确后，将学习历史喂入模型进行训练，目标和CoH不同的点在于训练模型而不是针对某个任务的训练。

这个方法假设对于任何可以生成学习历史集合的算法，都可以通过对过去动作行为进行行为克隆将其“蒸馏”成一个神经网络。在每次训练中，该方法选择一个随机的任务和一个子序列$h\subseteq H$作为数据进行训练，这样一来训练过程便与任务本身无关。

![Untitled](Read%20LLM%20Powered%20Autonomous%20Agents%2086be86301a6342758a6dadbff904c9a9/Untitled%202.png)

实际上，模型的上下文长度是很短的，所以需要每个任务的序列足够短才能构建起一个多任务序列，而每个多任务至少需要2-4个任务才能达到几乎完美的上下文中的强化学习算法。

在与ED（expert distillation），源策略，RL^2的比较中，AD的表现接近于RL^2，但训练速度远快于RL^2，此外，当使用源策略的部分训练历史作为条件时，AD的改进速度也比ED基准算法快得多。

## 组件二：记忆

### 记忆的种类

这里的记忆是指负责**获取，存储，保存和检索信息**的进程。如果把代理中的记忆和人类记忆相比较的话：

- 负责嵌入表示的记忆就相当于人类的感官记忆，负责原始输入的处理，包括文字、图片或其他模态的数据。
- 上下文学习的记忆就相当于人类的短期记忆，被上下文窗口的长度限制。
- 外部向量存储就相当于人类的长期记忆，代理可以随时查询。

最大内积搜索（MIPS）是一种用于查询外部向量存储的方法，当前常见的方法是使用 ANN 算法，查找 k 个最接近的点，在一点性能损失的前提下，获得很大的速度提升。比较常见的 ANN 算法有下列几个：

- LSH，Locality-Sensitive Hashing
- **[ANNOY](https://github.com/spotify/annoy)** (Approximate Nearest Neighbors Oh Yeah)
- **[HNSW](https://arxiv.org/abs/1603.09320)** (Hierarchical Navigable Small World)
- **[FAISS](https://github.com/facebookresearch/faiss)** (Facebook AI Similarity Search)
- **[ScaNN](https://github.com/google-research/google-research/tree/master/scann)** (Scalable Nearest Neighbors)

## 组件三：工具调用

> Tool use is a remarkable and distinguishing characteristic of human beings. We create, modify and utilize external objects to do things that go beyond our physical and cognitive limits.
> 

**MRKL** ([Karpas et al. 2022](https://arxiv.org/abs/2205.00445)),是一个自动代理的神经符号结构。一个 MRKL 系统包含一个专家模组的集合，在其中 LLM 起到路由器的作用，将每个查询请求引导到最合适的模组。

**TALM** (Tool Augmented Language Models; [Parisi et al. 2022](https://arxiv.org/abs/2205.12255)) and **Toolformer** ([Schick et al. 2023](https://arxiv.org/abs/2302.04761))微调了一个 LLM 让其学习如何使用外部工具。

ChatGPT 插件和 OpenAI API 的函数调用就是 LLM 使用外部工具的良好例子。

**HuggingGPT** ([Shen et al. 2023](https://arxiv.org/abs/2303.17580)) 是一个使用 ChatGPT 作为任务管理来选择 Huggingface 上合适的模型进行任务求解的框架，同时 ChatGPT 还会根据执行结果总结输出给用户。

![Untitled](Read%20LLM%20Powered%20Autonomous%20Agents%2086be86301a6342758a6dadbff904c9a9/Untitled%203.png)

<aside>
💡 从这张图上可以很清楚的看出 HuggingGPT 是和 ChatGPT 的交互过程

</aside>

这个系统包括4个部分：

1. 任务管理：LLM 作为大脑解析用户的请求，将每个任务解析成一个四元组$（task\ type,ID,dependecies,arguments）$，其中arguments可以为文本，图像URL，音频或视频URL等，dependecies表示当前任务依赖的前一个任务生成的新资源的id。特殊标记"-task_id"表示当前任务依赖具有特定id的依赖任务生成的文本、图片、音频或视频。
2. 选择模型：LLM 将任务分发给专家模组，模块再将请求构建成多选的问题，LLM 提供一系列可供选择的模型。
3. 执行任务：专家模组执行任务并输出结果。
4. 生成输出：LLM 将模组的执行结果进行总结并输出给用户。

以上是 HuggingGPT 的大致执行过程，但是要将其应用到实际生活中还需解决如下问题：

- 提升效率：LLM 的推理轮数和与其他模型的交互大大降低的过程的速度。
- 对于复杂任务，其需要一个很长的上下文窗口长度，而基于上文所说的，当前上下文窗口的长度是较短的。
- 当前 LLM 的输出和外部模型服务的稳定性仍需要提升。

**API-Bank** ([Li et al. 2023](https://arxiv.org/abs/2304.08244)) 是一个评估工具增强的 LLM 性能的基准。其包含53个常用的API工具，一个完整的工作增强 LLM 的工作流，以及264个带有注释的对话，其中涉及到了568个API调用。其执行原理与正常的API调用无异，LLM 在其中主要做了三个工作：

- 判断是否需要调用API
- 选择正确的API调用，如果API的输出不够好，LLM 需要迭代的修改输入。
- 基于API的结果做出反馈，如果结果不够令人满意，LLM 需要修改并重新调用API。

在这个过程中，API-Bank 从三个方面对 LLM 做出的决定的准确性进行基准评估：

- 等级一：评估调用API的能力，对于给定的 API 描述，模型需要决定是否调用该 API ，调用是否正确，能否对 API 的返回值做出正确的回应。
- 等级二：测试寻找API的能力，模型有时需要搜寻可能可以解决用户需求的 API，并且通过 API 文档学习如何使用。
- 等级三：评估除了调用和检索以外的能力，比如对于用户给定的复杂需求（安排会议，预定机票/餐厅等），模型可能需要调用多个 API 并将其整合。

### 事例学习

1. 科学研发代理
    
    **ChemCrow** ([Bran et al. 2023](https://arxiv.org/abs/2304.05376))是一个指定域名的代理，其使用 13 个专家设计的工具来完成有机合成，药物研发和材料设计等任务。其采用前面提到的 ReAct 和 MRKL 方法，并将 CoT 推理与相关的工具结合。
    
    有趣的是，在 LLM 方面的评估中，GPT-4 和 ChemCrow 不相上下，但是在人类专家的评估中，ChemCrow 的表现要远远超过 GPT-4